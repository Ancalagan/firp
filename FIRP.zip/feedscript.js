const event = document.getElementById("btn2");
event.onclick = function() {
  window.location.href = "events.html";
}
const event2 = document.getElementById("btn3");
event2.onclick = function() {
  window.location.href = "more.html";
}